<?php
$hashCode = password_hash('Abc123!@#', PASSWORD_BCRYPT);
echo $hashCode;



