CREATE table admin(
id integer PRIMARY KEY AUTO_INCREMENT,
email varchar(100) UNIQUE,
password varchar(60)

);
