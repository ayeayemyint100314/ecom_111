<?php

$batch = 111; // integer datatype
$name = "IMC"; // string data type
$temp = 33.5; // float data type
echo "<b><em>Hello Batch $batch, welcome to  ecommerce module</em></b>";
// defining function
function power($num1, $num2)
{
    return pow($num1, $num2);
}

$number1 = 2; // $studentName
$number2 = 6;
$result = power($number1, $number2);// calling function
echo "<br>result is $result";

?>